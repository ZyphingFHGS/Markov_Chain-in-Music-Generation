import pandas as pd
from music21 import chord, note
from collections import Counter


pd.set_option('display.max_columns', 999)


def get_notes_offset_duraion(part):
    notes = []
    notes_offset = []
    durations = []

    for i in part:
        notes_offset.append(float(i.offset))
        durations.append(float(i.duration.quarterLength))
        if isinstance(i, note.Note):
            notes.append(str(i.pitch))
        elif isinstance(i, chord.Chord):
            i = str(i).replace('>', '')
            chords = '|'.join(i.split()[1:])
            notes.append(chords)

    return notes, notes_offset, durations


def get_notes_transition_map(key_notes ,notes):
    notes_dictionary = {}
    notes_transition_map = {}

    for notes_ in key_notes:
        notes_dictionary[notes_] = []
    for notes_, next_notes in zip(list(notes), list(notes)[1:]):
        notes_dictionary[notes_].append(next_notes)

    for y_key in notes_dictionary.keys():
        tran_map = {}
        for x_key in notes_dictionary.keys():
            tran_map[x_key] = 0.0
        notes_transition_map[y_key] = tran_map
    for y_key in notes_dictionary.keys():
        new_notes = notes_dictionary[y_key]
        new_note_count = Counter(new_notes)
        for my_note_count in new_note_count.keys():
            notes_transition_map[y_key][my_note_count] = new_note_count[my_note_count] / len(new_notes)

    return notes_dictionary, notes_transition_map


def get_duration_transition_map(notes_dictionary ,notes_transition_matrix, melody, melody_durations):
    duration_dictionary = {}
    duration_transition_map = {}

    for single_note in list(notes_transition_matrix.columns):
        duration_dictionary[single_note] = []
    for notes, duration in zip(melody, melody_durations):
        duration_dictionary[notes].append(duration)

    for single_note in notes_dictionary.keys():
        duration_map = {}
        for each_duration in melody_durations:
            duration_map[each_duration] = 0.0
        duration_transition_map[single_note] = duration_map
    for single_note in notes_dictionary.keys():
        note_duration = duration_dictionary[single_note]
        note_duration_count = Counter(note_duration)
        for single_note_duration in note_duration_count.keys():
            duration_transition_map[single_note][single_note_duration] = \
                note_duration_count[single_note_duration] / len(note_duration)
    return duration_dictionary, duration_transition_map







