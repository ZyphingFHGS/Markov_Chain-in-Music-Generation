import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
from mpl_toolkits.axes_grid1 import make_axes_locatable
pd.set_option('display.max_columns', 9999)

def plot_matrix(mat):
    print(mat.index)
    x_labels = [f"{i}" for i in mat.index]
    y_labels = [f"{i}" for i in mat.index]

    fig = plt.figure(figsize=(10, 10))
    plt.subplot(1, 1, 1)
    ax = plt.gca()
    im = plt.imshow(mat)

    divider = make_axes_locatable(ax)
    cax = divider.append_axes("right", size="5%", pad=0.3)
    plt.colorbar(im, cax=cax)

    x = 0.0
    y = 0.0
    for i in mat.index:
        for j in mat.index:
            if mat[i][j] != 0.0:
                ax.text(x - 0.25, y + 0.06, "{:.2f}".format(mat[i][j]), color='white', size='xx-large')
            y += 1
        x += 1
        y = 0


    ax.set_xticks(range(len(x_labels)))
    ax.set_xticklabels(x_labels)

    ax.set_yticks(range(len(y_labels)))
    ax.set_yticklabels(y_labels)

    # 避免横纵坐标太密集
    # ax.xaxis.set_major_locator(ticker.MultipleLocator(base=5))
    # ax.yaxis.set_major_locator(ticker.MultipleLocator(base=5))

    ax.set_title("Harmony Notes Transition Matrix")
    plt.savefig("Harmony Notes Transition Matrix.png", dpi=1000)