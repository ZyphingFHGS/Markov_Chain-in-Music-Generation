import pandas as pd
import numpy as np
from music21 import converter, chord, note, instrument, stream
from collections import Counter
import random

pd.set_option('display.max_columns', 999)


def generate_song(melody_matrix, harmony_matrix, duration_matrix,harmony_duration_matrix):
    melody = []
    melody_duration_gen = []
    harmony = []
    harmony_duration_gen = []

    count = 32 * 4
    duration_count = 0

    melody_note = random.choice(list(melody_matrix.index))
    melody_duration = float(np.random.choice(duration_matrix.loc[melody_note].index,
                                             p=duration_matrix.loc[melody_note].values))
    duration_count += melody_duration

    while duration_count <= count:
        melody.append(melody_note)
        melody_duration_gen.append(melody_duration)

        melody_note = np.random.choice(melody_matrix.loc[melody_note].index,
                                       p=melody_matrix.loc[melody_note].values)
        melody_duration = float(np.random.choice(duration_matrix.loc[melody_note].index,
                                                 p=duration_matrix.loc[melody_note].values))
        duration_count += melody_duration

    duration_count = 0
    harmony_note = random.choice(list(harmony_matrix.index))
    # harmony_duration = 4.0
    harmony_duration = float(np.random.choice(harmony_duration_matrix.loc[harmony_note].index,
                                              p=harmony_duration_matrix.loc[harmony_note].values))
    duration_count += harmony_duration

    while duration_count <= count:
        harmony.append(harmony_note)
        harmony_duration_gen.append(harmony_duration)

        harmony_note = np.random.choice(harmony_matrix.loc[harmony_note].index,
                                        p=harmony_matrix.loc[harmony_note].values)
        harmony_duration = float(np.random.choice(harmony_duration_matrix.loc[harmony_note].index,
                                                   p=harmony_duration_matrix.loc[harmony_note].values))
        duration_count += harmony_duration

    return melody, melody_duration_gen, harmony, harmony_duration_gen


def ensemble(notes, duration):
    p = stream.Part()
    print(notes)
    print(duration)
    for note_, duration_ in zip(notes, duration):
        print(note_, duration_)
        if duration_ == 0.0:
            continue
        else:
            if "|" not in note_:
                ind_note = note.Note(note_)
                ind_note.quarterLength = duration_
                p.append(ind_note)
            else:
                split_notes = note_.split("|")
                chords = chord.Chord(split_notes)
                chords.quarterLength = duration_
                p.append(chords)
    return p
