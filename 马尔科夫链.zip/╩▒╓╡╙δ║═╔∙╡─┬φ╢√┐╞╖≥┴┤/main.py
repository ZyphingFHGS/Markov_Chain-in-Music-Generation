import pandas as pd
import numpy as np
from music21 import converter, chord, note, instrument, stream
from collections import Counter
import random
from matplotlib import pyplot as plt
from preprocess import *
from generator import *
from visualization import *
pd.set_option('display.max_columns', 9999)


def get_midi_part(file_path):
    # 读取midi并按声部和乐器划分
    midi = converter.parse(file_path)
    parts = instrument.partitionByInstrument(midi)

    melody = parts.parts[0]
    harmony = parts.parts[1]
    return melody, harmony


if __name__ == "__main__":
    # load data
    data_path = 'All Too Well.mid'
    melody_part, harmony_part = get_midi_part(data_path)
    # basic information
    melody_notes, melody_offset, melody_duration = get_notes_offset_duraion(melody_part)
    harmony_notes, harmony_offset, harmony_duration = get_notes_offset_duraion(harmony_part)
    melody_key_notes = set(key for key in melody_notes)
    harmony_key_notes = set(key for key in harmony_notes)
    #preprocess
    melody_notes_dictionary, melody_notes_transition_map = get_notes_transition_map(melody_key_notes, melody_notes)
    harmony_notes_dictionary, harmony_notes_transition_map = get_notes_transition_map(harmony_key_notes, harmony_notes)

    melody_notes_transition_matrix = pd.DataFrame(melody_notes_transition_map).T
    harmony_notes_transition_matrix = pd.DataFrame(harmony_notes_transition_map).T

    melody_notes_transition_matrix = melody_notes_transition_matrix.drop(
        melody_notes_transition_matrix[melody_notes_transition_matrix.sum(1).values == 0].index
    )
    harmony_notes_transition_matrix = harmony_notes_transition_matrix.drop(
        harmony_notes_transition_matrix[harmony_notes_transition_matrix.sum(1).values == 0].index
    )

    melody_duration_dictionary, melody_duration_transition_map = \
        get_duration_transition_map(melody_notes_dictionary, melody_notes_transition_matrix, melody_notes, melody_duration)

    melody_duration_transition_matrix = pd.DataFrame(melody_duration_transition_map).T

    harmony_duration_dictionary, harmony_duration_transition_map = \
        get_duration_transition_map(harmony_notes_dictionary, harmony_notes_transition_matrix, harmony_notes,
                                    harmony_duration)

    harmony_duration_transition_matrix = pd.DataFrame(harmony_duration_transition_map).T

    melody_duration_transition_matrix = melody_duration_transition_matrix.rename(
        columns={'1/3': '0.33', '2/3': '0.66', '4/3': '1.33', '5/3': '1.66', '7/3': '2.33', '8/3': '2.66',
                 '10/3': '3.33', '11/3': '3.66', '16/3': '5.33', '22/3': '7.33', '23/3': '7.66', '25/3': '8.33'})
    harmony_duration_transition_matrix = harmony_duration_transition_matrix.rename(
        columns={'1/3': '0.33', '2/3': '0.66', '4/3': '1.33', '5/3': '1.66', '7/3': '2.33', '8/3': '2.66',
                 '10/3': '3.33', '11/3': '3.66', '16/3': '5.33', '22/3': '7.33', '23/3': '7.66', '25/3': '8.33'})

    # generator
    melody, melody_duration_gen, harmony, harmony_duration_gen = generate_song(melody_notes_transition_matrix,
                                                                               harmony_notes_transition_matrix,
                                                                               melody_duration_transition_matrix,
                                                                               harmony_duration_transition_matrix)
    score = stream.Score()
    p1 = ensemble(melody, melody_duration_gen)
    p1.id = 'melody'

    p2 = ensemble(harmony, harmony_duration_gen)
    p2.id = 'harmony'

    score.insert(p1)
    score.insert(p2)
    im_1 = plt.imshow(harmony_duration_transition_matrix)
    plt.savefig("Harmony Duration Transition Matrix.png", dpi=1000)
    # plot_matrix(harmony_notes_transition_matrix)

    #score.write('midi', fp='your_song.midi')
