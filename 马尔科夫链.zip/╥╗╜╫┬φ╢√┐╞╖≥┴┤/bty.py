from music21 import *
import numpy
import random

mid = converter.parse("D:\\Documents\\WeChat Files\\wxid_yeuwk7lfmzd722\\FileStorage\\File\\2022-05\\midiclassics\\Arndt\\Nola, Novelty piano solo.mid")

cnt_list = []

progress = 0

for note1 in mid[0].flat.notes:
    if cnt_list.count(note1) == 0:
        cnt_list.append(note1)
    progress += 1

cnt = len(cnt_list)
print(cnt)

matrix = numpy.zeros((cnt, cnt), numpy.uint16)

pre = None
for n, cur in enumerate(mid[0].flat.notes):
    if pre is not None:
        for i in range(0, cnt):
            if cnt_list[i] == pre:
                pre_id = i
            if cnt_list[i] == cur:
                cur_id = i
        matrix[pre_id, cur_id] += 1
    pre = cur
    if n % 10 == 0:
        print(n, '/', progress)

print(matrix)


def rand_index(weight):
    r = random.randint(0, sum(weight))
    tot = 0
    idx = 0
    for idx, n in enumerate(weight):
        tot += n
        if tot >= r:
            break
    return idx


out = stream.Part()
score = stream.Score()

cur = random.randint(0, cnt - 1)
for i in range(500):
    ref = cnt_list[cur]
    if type(ref) == note.Note:
        t = note.Note()
        t.pitch = ref.pitch
        t.duration = ref.duration
    else:
        t = chord.Chord()
        t.pitches = ref.pitches
        t.duration = ref.duration
    out.append(t)
    cur = rand_index(matrix[cur])
    if i % 10 == 0:
        print(i, '/', 500)

score.insert(out)

out = stream.Part()

cur = random.randint(0, cnt - 1)
for i in range(500):
    ref = cnt_list[cur]
    if type(ref) == note.Note:
        t = note.Note()
        t.pitch = ref.pitch
        t.duration = ref.duration
    else:
        t = chord.Chord()
        t.pitches = ref.pitches
        t.duration = ref.duration
    out.append(t)
    cur = rand_index(matrix[cur])
    if i % 10 == 0:
        print(i, '/', 500)

score.insert(out)

score.write('xml', fp='out3.xml')
